////////////////////////////////////////////////////////////////
//Austin Morrell//
//Septemper 9th 2015//
//September 14th 2015//
//Wumpus World Problem//
///////////////////////////////////////////////////////////////

#include <iostream>
#include "Source.h"
#include <string>
using namespace std;

char moveChoice;

class Player
{
public:
	int px = 0;
	int py = 3;
	bool arrow = 0;
};

Player Wumpus;
Player You;
Player Pit;
Player Pit1;
Player Pit2;
Player Gold;
int win = 0;
bool wombo = 1;
bool gotGold = 0;

void move()
{
	if (You.py > 3)
	{
		system("cls");
		cout << "You can't go through walls!";
		You.py = You.py - 2;
		system("pause");
		system("cls");
	}
	if (You.px > 3)
	{
		system("cls");
		cout << "You can't go through walls!";
		You.px = You.px - 2;
		system("pause");
		system("cls");
	}
	else if (moveChoice == 'a')
	{
		You.px = You.px - 1;
	}
	else if (moveChoice == 'w')
	{
		You.py = You.py + 1;
	}
	else if (moveChoice == 's')
	{
		You.py = You.py - 1;
	}
	else if (moveChoice == 'd')
	{
		You.px = You.px + 1;
	}
}

string places[4][4];

void Event()
{
	system("cls");
	//Mostly everything here is for stage 1 of the adventure//
	if (wombo == 1)
	{
		if (Wumpus.px == You.px && Wumpus.py == You.py)
		{
			cout << "You dead son! The Wumpus got ya!\n";
			system("pause");
			exit(0);
		}
	}
	if (Pit.px == You.px && Pit.py == You.py)
	{
		cout << "Feel into the Pit. Dang no one can survive that fall. GG.\n";
		system("pause");
		exit(0);
	}
	if (Pit1.px == You.px && Pit1.py == You.py)
	{
		cout << "Feel into the Pit. Dang no one can survive that fall. GG.\n";
		system("pause");
		exit(0);
	}
	if (Pit2.px == You.px && Pit2.py == You.py)
	{
		cout << "Feel into the Pit. Dang no one can survive that fall. GG.\n";
		system("pause");
		exit(0);
	}
	if (You.px == 1 && You.py == 2 && You.arrow == 0)
	{
		cout << "You got the arrow! Now you can shank the wumpus!\n";
		You.arrow = 1;
		system("pause");
		system("cls");
	}
	if (You.arrow == 1 && You.px == 0 && You.py == 0 && moveChoice == 'x' && gotGold == 0)
	{
		cout << "You killed dat wumpus! Yahhhh!\n";
		You.arrow = 0;
		wombo = 0;
		system("pause");
		system("cls");
	}
	if (You.px == 3 && You.py == 0)
	{
		cout << "Yummmmmmm! Got some of that money $$$$$.";
		gotGold = 1;
		system("pause");
		system("cls");
	}
	if (You.px == 0 && You.py == 3 && gotGold == 1)
	{
		win = 1;
	}
	//Nothing past here will in the function will apply after getting the Gold//

	if (gotGold == 0)
	{
	if (You.px == Pit.px + 1 || You.py == Pit.py + 1)
	{
		cout << "You feel a breeze close by!\n";
		system("pause");
		system("cls");
	}
	if (You.px == Pit1.px + 1 || You.py == Pit1.py + 1)
	{
		cout << "You feel a breeze close by!\n";
		system("pause");
		system("cls");
	}
	if (You.px == Pit2.px + 1 || You.py == Pit2.py + 1)
	{
		cout << "You feel a breeze close by!\n";
		system("pause");
		system("cls");
	}
	if (You.px == Pit.px - 1 || You.py == Pit.py - 1)
	{
		cout << "You feel a breeze close by!\n";
		system("pause");
		system("cls");
	}
	if (You.px == Pit1.px - 1 || You.py == Pit1.py - 1)
	{
		cout << "You feel a breeze close by!\n";
		system("pause");
		system("cls");
	}
	if (You.px == Pit2.px - 1 || You.py == Pit2.py - 1)
	{
		cout << "You feel a breeze close by!\n";
		system("pause");
		system("cls");
	}
	if (You.px == Wumpus.px + 1 || You.py == Wumpus.py + 1 && wombo == 1)
	{
		cout << "You smell something real stinky close by! -_-\n";
		system("pause");
		system("cls");
	}
	if (You.px == Wumpus.px - 1 || You.py == Wumpus.py - 1 && wombo == 1)
	{
		cout << "You smell something real stinky close by! -_-\n";
		system("pause");
		system("cls");
	}
}
}

//Start Wumpus World Problem.//
int main()
{
	cout << "      Welcome to Wumpus World!\n";
	cout << "You are in a dungeon with gold and\nyour goal is to get that gold without falling into the pits\nor running into the Wumpus.\n";
	cout << "However, you can kill the Wumpus, but you need to time your shot\njust right. Ok Ready? Go!\n";
	system("pause");

	Wumpus.px = 1;
	Wumpus.py = 0;
	
	Pit.px = 2;
	Pit.py = 1;

	Pit1.px = 3;
	Pit1.py = 1;

	Pit2.px = 1;
	Pit2.py = 3;

	Gold.px = 3;
	Gold.py = 0;

	system("cls");
	while (win == 0)
	{
		cout << "Movement:\nUp - w\nDown - s\nLeft - a\nRight - d\nFire - x\n";
		cout << "(" << You.px << "," << You.py << ")\n";
		cin >> moveChoice;
		move();
		Event();
		system("cls");
	}
	system("cls");
	cout << "Congrats you win! You got dat butter!\n";
	system("pause");
}